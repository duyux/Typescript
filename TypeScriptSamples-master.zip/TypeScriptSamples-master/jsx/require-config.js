requirejs.config({
    paths: {
        react: ['/node_modules/react/dist/react'],
        jquery: ['/node_modules/jquery/dist/jquery']
    }
});
