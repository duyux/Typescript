**Setup jspm and install jspm dependencies**
```
npm install -g jspm@beta
jspm install
jspm dl-loader --edge
```

**run:**
- install http-server package via
 ```
 npm install -g http-server 
 ```
- run server (if port 8080 it taken, pick any port that is free)
 ```
 http-server -p 8080
 ```
