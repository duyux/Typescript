/// <reference path="angularjs/angular.d.ts" />
/// <reference path="jasmine/jasmine.d.ts" />
/// <reference path="karma-jasmine/karma-jasmine.d.ts" />
/// <reference path="angularjs/angular-mocks.d.ts" />
/// <reference path="jquery/jquery.d.ts" />
/// <reference path="angular-protractor/angular-protractor.d.ts" />
/// <reference path="selenium-webdriver/selenium-webdriver.d.ts" />
