interface GreetingState {
  greetings: string[];
  newGreeting: string;
}

export default GreetingState;
